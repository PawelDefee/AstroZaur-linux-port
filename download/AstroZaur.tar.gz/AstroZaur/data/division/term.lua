astro.division(
    "Term",
    {
	{ from=0, to=6, "Jupiter" },
	{ from=6, to=14, "Venus" },
	{ from=14, to=21, "Mercury" },
	{ from=21, to=26, "Mars" },
	{ from=26, to=30, "Saturn" },
	
	{ from=30, to=38, "Venus" },
	{ from=38, to=45, "Mercury" },
	{ from=45, to=52, "Jupiter" },
	{ from=52, to=56, "Saturn" },
	{ from=56, to=60, "Mars" },

	{ from=60, to=67, "Mercury" },
	{ from=67, to=74, "Jupiter" },
	{ from=74, to=81, "Venus" },
	{ from=81, to=85, "Saturn" },
	{ from=85, to=90, "Mars" },

	{ from=90, to=96, "Mars" },
	{ from=96, to=103, "Jupiter" },
	{ from=103, to=110, "Mercury" },
	{ from=110, to=117, "Venus" },
	{ from=117, to=120, "Saturn" },

	{ from=120, to=126, "Saturn" },
	{ from=126, to=133, "Mercury" },
	{ from=133, to=139, "Venus" },
	{ from=139, to=145, "Jupiter" },
	{ from=145, to=150, "Mars" },

	{ from=150, to=157, "Mercury" },
	{ from=157, to=163, "Venus" },
	{ from=163, to=168, "Jupiter" },
	{ from=168, to=174, "Saturn" },
	{ from=174, to=180, "Mars" },

	{ from=180, to=186, "Saturn" },
	{ from=186, to=191, "Venus" },
	{ from=191, to=199, "Jupiter" },
	{ from=199, to=204, "Mercury" },
	{ from=204, to=210, "Mars" },

	{ from=210, to=216, "Mars" },
	{ from=216, to=224, "Jupiter" },
	{ from=224, to=231, "Venus" },
	{ from=231, to=237, "Mercury" },
	{ from=237, to=240, "Saturn" },

	{ from=240, to=248, "Jupiter" },
	{ from=248, to=254, "Venus" },
	{ from=254, to=259, "Mercury" },
	{ from=259, to=265, "Saturn" },
	{ from=265, to=270, "Mars" },

	{ from=270, to=276, "Venus" },
	{ from=276, to=282, "Mercury" },
	{ from=282, to=289, "Jupiter" },
	{ from=289, to=295, "Mars" },
	{ from=295, to=300, "Saturn" },
	
	{ from=300, to=306, "Saturn" },
	{ from=306, to=312, "Mercury" },
	{ from=312, to=320, "Venus" },
	{ from=320, to=325, "Jupiter" },
	{ from=325, to=330, "Mars" },

	{ from=330, to=338, "Venus" },
	{ from=338, to=344, "Jupiter" },
	{ from=344, to=350, "Mercury" },
	{ from=350, to=356, "Mars" },
	{ from=356, to=360, "Saturn" }
    }
)
