astro.division(
    "Triplicitet day",
    {
	{ from=0, size=30, "Sun" },
	{ "Venus" },
	{ "Saturn" },
	{ "Mars" },
	{ "Sun" },
	{ "Venus" },
	{ "Saturn" },
	{ "Mars" },
	{ "Sun" },
	{ "Venus" },
	{ "Saturn" },
	{ "Mars" }
   }
)

astro.division(
    "Triplicitet night",
    {
	{ from=0, size=30, "Jupiter" },
	{ "Moon" },
	{ "Mercury" },
	{ "Mars" },
	{ "Jupiter" },
	{ "Moon" },
	{ "Mercury" },
	{ "Mars" },
	{ "Jupiter" },
	{ "Moon" },
	{ "Mercury" },
	{ "Mars" }
   }
)
