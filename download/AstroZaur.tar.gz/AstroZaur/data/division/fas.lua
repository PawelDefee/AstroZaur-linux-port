astro.division(
    "Fas",
    {
	{ size=10, "Mars" }, { "Sun" }, { "Venus" },
	{ "Mercury" }, { "Moon" }, { "Saturn" },
	{ "Jupiter" }, { "Mars" }, { "Sun" },
	{ "Venus" }, { "Mercury" }, { "Moon" },
	{ "Saturn" }, { "Jupiter" }, { "Mars" },
	{ "Sun" }, { "Venus" }, { "Mercury" },
	{ "Moon" }, { "Saturn" }, { "Jupiter" },
	{ "Mars" }, { "Sun" }, { "Venus" },
	{ "Mercury" }, { "Moon" }, { "Saturn" },
	{ "Jupiter" }, { "Mars" }, { "Sun" },
	{ "Venus" }, { "Mercury" }, { "Moon" },
	{ "Saturn" }, { "Jupiter" }, { "Mars" }
    }
)
