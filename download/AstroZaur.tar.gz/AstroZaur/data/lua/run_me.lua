local w = gui.window(320, 200, "Lua test")
w.show()
