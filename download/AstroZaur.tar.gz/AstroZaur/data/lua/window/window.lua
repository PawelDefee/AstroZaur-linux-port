local window = ...
local menu = window.menu[2]

menu.item(
    { label = "New", callback = program.newwindow }
)
